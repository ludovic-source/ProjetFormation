package com.example.portailci.exposition.security;

public class CustomUserDetailsServiceTest {


}
