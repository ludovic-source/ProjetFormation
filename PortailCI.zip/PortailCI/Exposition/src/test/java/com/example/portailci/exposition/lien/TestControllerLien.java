package com.example.portailci.exposition.lien;

import com.example.portailci.application.lien.IManagementLien;
import com.example.portailci.application.lien.ManagementLienImpl;
import com.example.portailci.domain.lien.LienEntity;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
@EnableWebMvc
public class TestControllerLien {

    @Autowired
    private MockMvc mockMvc;

    // ajouté après pour les find
    @MockBean
    private IManagementLien managementLien;

    @Autowired
    private WebApplicationContext wac;

    @MockBean
    private ControllerLien controllerLien;

    private LienEntity lien = new LienEntity();

    @BeforeEach
    public void init() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
    }

    @Test
    public void tester_create_lien_reussi() throws Exception {

        initLien();

        mockMvc.perform( MockMvcRequestBuilders
                .post("/portailci/lien/create")
                .content(asJsonString(lien))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        //        .andExpect(MockMvcResultMatchers.jsonPath("$.statut").exists());

    }

    @Test
    public void tester_create_lien_parametre_vide() throws Exception {

        mockMvc.perform( MockMvcRequestBuilders
                .post("/portailci/lien/create")
                .content(asJsonString(null))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void tester_modifier_lien_reussi() throws Exception {

        initLien();
        mockMvc.perform( MockMvcRequestBuilders
                .post("/portailci/lien/modifier")
                .content(asJsonString(lien))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void tester_modifier_lien_parametre_vide() throws Exception {
        mockMvc.perform( MockMvcRequestBuilders
                .post("/portailci/lien/modifier")
                .content(asJsonString(null))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void tester_publier_lien_reussi() throws Exception {

        initLien();
        mockMvc.perform( MockMvcRequestBuilders
                .post("/portailci/lien/publier")
                .content(asJsonString(lien))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void tester_publier_lien_parametre_vide() throws Exception {
        mockMvc.perform( MockMvcRequestBuilders
                .post("/portailci/lien/publier")
                .content(asJsonString(null))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void tester_depublier_lien_reussi() throws Exception {

        initLien();
        mockMvc.perform( MockMvcRequestBuilders
                .post("/portailci/lien/depublier")
                .content(asJsonString(lien))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void tester_depublier_lien_parametre_vide() throws Exception {
        mockMvc.perform( MockMvcRequestBuilders
                .post("/portailci/lien/depublier")
                .content(asJsonString(null))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void tester_findById_lien_reussi() throws Exception {

        initLien();
        when(managementLien.findById(1)).thenReturn(lien);

       this.mockMvc.perform(MockMvcRequestBuilders
               .get("/portailci/lien/find/id/{id}", 1))
               .andDo(print()).andExpect(status().isOk())
       //        .andExpect(jsonPath("$[0].id").exists())
               .andReturn();


        /*
        //final String result = mockMvc.perform( MockMvcRequestBuilders
        mockMvc.perform( MockMvcRequestBuilders
                .get("/portailci/lien/find/id/{id}", 1)
                .accept(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").exists())
        //        .andExpect(jsonPath("$[0].id").exists())
        //        .andExpect(content().string(containsString("statut")));
                .andReturn().getResponse().getContentAsString();

        //assertThat(result).isEqualTo(lien); */
    }

    /* ne fonctionne pas
    @Test
    public void tester_findByIdLien_parametre_non_renseigné() throws Exception {
        mockMvc.perform( MockMvcRequestBuilders
                .get("/portailci/lien/find/id/{id}", 0)
                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isBadRequest());
    }
    */


    @Test
    public void tester_findByIdLien_reussi() throws Exception {
        mockMvc.perform( MockMvcRequestBuilders
                .get("/portailci/lien/find/id/{id}", 1)
                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk());
    }

    @Test
    public void findAllByThematique_reussi() throws Exception {
        mockMvc.perform( MockMvcRequestBuilders
                .get("/portailci/lien/find/thematique/{id}", 1)
                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk());
    }

    /* ne fonctionne pas
    @Test
    public void findAllByThematique_parametre_vide() throws Exception {
        mockMvc.perform( MockMvcRequestBuilders
                .get("/portailci/lien/find/thematique/{id}", 0)
                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isBadRequest());
    }
    */

    @Test
    public void tester_getAllLiensDepublies_reussi() throws Exception {

        initLien();
        List<LienEntity> resultLiens = new ArrayList<>();
        resultLiens.add(lien);
        when(managementLien.getAllLiensDepublies()).thenReturn(resultLiens);

        mockMvc.perform( MockMvcRequestBuilders
                .get("/portailci/lien/find/depublies")
                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk());
        //        .andExpect(jsonPath("$[0].id").exists());
    }

    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void initLien() {
        lien.setId(1);
        lien.setNom("lien de test");
        lien.setDescription("utilisé uniquement pour les tests");
        lien.setMode_affichage(true);
        lien.setUrl("http://coucou/tests");
    }

}
