package com.example.portailci.exposition.thematique;

import com.example.portailci.domain.thematique.ThematiqueEntity;
import org.springframework.web.multipart.MultipartFile;

public class ThematiqueDTO {
    private ThematiqueEntity thematique;
    private MultipartFile file;

    public ThematiqueEntity getThematique() {
        return thematique;
    }

    public void setThematique(ThematiqueEntity thematique) {
        this.thematique = thematique;
    }

    public MultipartFile getFile() {
        return file;
    }

    public void setFile(MultipartFile file) {
        this.file = file;
    }
}
