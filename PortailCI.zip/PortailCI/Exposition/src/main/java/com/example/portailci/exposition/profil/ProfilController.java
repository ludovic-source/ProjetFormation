package com.example.portailci.exposition.profil;


import com.example.portailci.application.profil.IProfilManagement;
import com.example.portailci.domain.profil.ProfilEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@RestController
@RequestMapping("/portailci/profils")
public class ProfilController {

    @Autowired
    private IProfilManagement profilManagement;

    @Autowired
    private ProfilMapper profilMapper;

    @PreAuthorize("hasAuthority('Administration') and hasAuthority('Consultation')")
    @GetMapping(value = "/get/{id}", produces = {"application/json"})
    public ResponseEntity<ProfilFullDTO> getProfilById (Long id) {

        ProfilFullDTO profilFullDTO = profilMapper.mapToDto(profilManagement.findByID(id));
        return new ResponseEntity<>(profilFullDTO, HttpStatus.OK);

    }

    @PreAuthorize("hasAuthority('Administration') and hasAuthority('Consultation')")
    @GetMapping(value = "/get", produces = {"application/json"})
    public ResponseEntity<Set<ProfilFullDTO>> getProfils() {

        Set<ProfilFullDTO> profilFullDTOSet = profilMapper.mapToDtoSet(profilManagement.findAll());
        return new ResponseEntity<>(profilFullDTOSet, HttpStatus.OK);
    }

    @PreAuthorize("hasAuthority('Administration') and hasAuthority('Création')")
    @PostMapping("/create")
    public ResponseEntity<ProfilFullDTO> createProfil(@NotNull @RequestBody final ProfilLightDTO profilLightDTO) {

        ProfilEntity profilEntity = profilMapper.mapToEntity(profilLightDTO);

        ProfilFullDTO profilFullDTO = profilMapper.mapToDto(profilManagement.create(profilEntity));

        return new ResponseEntity<>(profilFullDTO, HttpStatus.CREATED);
    }

    @PreAuthorize("hasAuthority('Administration') and hasAuthority('Modification')")
    @PutMapping("/update")
    public ResponseEntity<ProfilFullDTO> updateProfil(@NotNull @RequestBody final ProfilFullDTO profilFullDTO) {

        ProfilEntity profilEntity = profilMapper.mapToEntity(profilFullDTO);

        ProfilFullDTO updatedProfil = profilMapper.mapToDto(profilManagement.update(profilEntity));

        return new ResponseEntity<>(updatedProfil, HttpStatus.OK);
    }

    @PreAuthorize("hasAuthority('Administration') and hasAuthority('Suppression')")
    @DeleteMapping("/delete/{id}")
    public HttpStatus deleteProfil (@NotNull @PathVariable final Long id) {
        profilManagement.delete(id);
        return HttpStatus.OK;
    }
}
