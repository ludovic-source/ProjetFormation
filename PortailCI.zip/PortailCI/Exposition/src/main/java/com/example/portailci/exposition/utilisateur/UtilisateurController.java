package com.example.portailci.exposition.utilisateur;

import com.example.portailci.application.utilisateur.IUtilisateurManagement;
import com.example.portailci.domain.utilisateur.UtilisateurEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;
import java.util.List;

@RestController
@RequestMapping("/portailci/utilisateurs")
public class UtilisateurController {

    private static Logger logger = LoggerFactory.getLogger(UtilisateurController.class);

    @Autowired
    private IUtilisateurManagement utilisateurManagement;

    @Autowired
    private UtilisateurMapper utilisateurMapper;

    @PostMapping("/create")
    //@PreAuthorize("hasAuthority('Administration') and hasAuthority('Création')")
    public ResponseEntity<UtilisateurFullDTO> createUtilisateur(@NotNull @RequestBody final UtilisateurLightDTO utilisateurDTO) {

        UtilisateurEntity createdUtilisateurEntity = utilisateurManagement.create(utilisateurMapper.mapToEntity(utilisateurDTO));

        UtilisateurFullDTO createdUtilisateurDTO = utilisateurMapper.mapToDto(createdUtilisateurEntity);


        return new ResponseEntity<>(createdUtilisateurDTO, HttpStatus.CREATED);
    }

    @PreAuthorize("hasAuthority('Administration') and hasAuthority('Consultation')")
    @GetMapping(value = "/getByUID/{utilisateurUid}", produces = {"application/json"})
    public ResponseEntity<UtilisateurFullDTO> getUtilisateurByUid(@PathVariable final String utilisateurUid) {

        UtilisateurFullDTO utilisateurFullDTO = new UtilisateurFullDTO();

        try{
            utilisateurFullDTO = utilisateurMapper.mapToDto(utilisateurManagement.findByUID(utilisateurUid));

            return new ResponseEntity<>(utilisateurFullDTO, HttpStatus.OK);
        }
        catch(Exception e) {
            //On retourne un utilisateur vide et un code HTTP 400 Bad Request
            return new ResponseEntity<>(utilisateurFullDTO, HttpStatus.BAD_REQUEST);
        }


    }

    @PreAuthorize("hasAuthority('Administration') and hasAuthority('Consultation')")
    @GetMapping(value = "/get/{id}", produces = {"application/json"})
    public ResponseEntity<UtilisateurFullDTO> getUtilisateurById(@PathVariable final Long id) {

        UtilisateurFullDTO utilisateurFullDTO = utilisateurMapper.mapToDto(utilisateurManagement.findByID(id));

        return new ResponseEntity<> (utilisateurFullDTO, HttpStatus.OK);
    }

    @PreAuthorize("hasAuthority('Administration') and hasAuthority('Consultation')")
    @GetMapping(value = "/get", produces = {"application/json"})
    public ResponseEntity<List<UtilisateurFullDTO>> getUtilisateurs () {

        List<UtilisateurEntity> utilisateurEntityList = utilisateurManagement.findAll();

        List<UtilisateurFullDTO> listeUtilisateurs = utilisateurMapper.mapToDtoList(utilisateurEntityList);

        return new ResponseEntity<>(listeUtilisateurs, HttpStatus.OK);
    }

    @PreAuthorize("hasAuthority('Administration') and hasAuthority('Suppression')")
    @DeleteMapping("/delete/{id}")
    public HttpStatus deleteUtitlisateur(@PathVariable final Long id) {

        utilisateurManagement.delete(id);

        return HttpStatus.OK;
    }

    @PreAuthorize("hasAuthority('Administration') and hasAuthority('Modification')")
    @PutMapping("/update")
    public ResponseEntity<UtilisateurFullDTO> updateUtilisateur(@NotNull @RequestBody final UtilisateurFullDTO utilisateurDTO) {

        UtilisateurEntity createdUtilisateurEntity = utilisateurManagement.update(utilisateurMapper.mapToEntity(utilisateurDTO));

        UtilisateurFullDTO createdUtilisateurDTO = utilisateurMapper.mapToDto(createdUtilisateurEntity);

        return new ResponseEntity<>(createdUtilisateurDTO, HttpStatus.OK);
    }
}
