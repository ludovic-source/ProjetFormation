package com.example.portailci.exposition.utilisateur;

import com.example.portailci.domain.profil.ProfilEntity;

public class UtilisateurLightDTO  {

    private String UID;
    private String nom;
    private String prenom;
    private String motDePasse;
    private String UOAffectation;
    private String siteExercice;
    private String fonction;
    private ProfilEntity profil;

    public UtilisateurLightDTO() {
    }

    public UtilisateurLightDTO(String UID, String nom, String prenom, String motDePasse, String UOAffectation, String siteExercice, String fonction, ProfilEntity profil) {
        this.UID = UID;
        this.nom = nom;
        this.prenom = prenom;
        this.motDePasse = motDePasse;
        this.UOAffectation = UOAffectation;
        this.siteExercice = siteExercice;
        this.fonction = fonction;
        this.profil = profil;
    }

    public String getUID() {
        return UID;
    }

    public void setUID(String UID) {
        this.UID = UID;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getMotDePasse() {
        return motDePasse;
    }

    public void setMotDePasse(String motDePasse) {
        this.motDePasse = motDePasse;
    }

    public String getUOAffectation() {
        return UOAffectation;
    }

    public void setUOAffectation(String UOAffectation) {
        this.UOAffectation = UOAffectation;
    }

    public String getSiteExercice() {
        return siteExercice;
    }

    public void setSiteExercice(String siteExercice) {
        this.siteExercice = siteExercice;
    }

    public String getFonction() {
        return fonction;
    }

    public void setFonction(String fonction) {
        this.fonction = fonction;
    }

    public ProfilEntity getProfil() {
        return profil;
    }

    public void setProfil(ProfilEntity profil) {
        this.profil = profil;
    }
}
