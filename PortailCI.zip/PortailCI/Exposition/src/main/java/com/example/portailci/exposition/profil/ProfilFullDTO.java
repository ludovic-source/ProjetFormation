package com.example.portailci.exposition.profil;

import com.example.portailci.exposition.droit.DroitDTO;

import java.util.Set;

public class ProfilFullDTO {

    private Long id;
    private String nom;
    private String description;
    private Set<DroitDTO> droits;

    public ProfilFullDTO() {}

    public ProfilFullDTO(Long id, String nom, String description, Set<DroitDTO> droits) {
        this.id = id;
        this.nom = nom;
        this.description = description;
        this.droits = droits;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Set<DroitDTO> getDroits() {
        return droits;
    }

    public void setDroits(Set<DroitDTO> droits) {
        this.droits = droits;
    }
}
