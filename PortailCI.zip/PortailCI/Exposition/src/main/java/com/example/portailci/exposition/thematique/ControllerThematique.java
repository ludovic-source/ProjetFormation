package com.example.portailci.exposition.thematique;

import com.example.portailci.application.thematique.IManagementThematique;
import com.example.portailci.domain.thematique.ThematiqueEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/portailci/thematique")
public class ControllerThematique {

    @Autowired
    IManagementThematique managementThematique;

    @PostMapping("/create")
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority('Création')")
    public ThematiqueEntity create(@RequestBody ThematiqueEntity thematique) {
        System.out.println("<Controller> Thématique - create : " + thematique.getNom());
        if (thematique != null) {
            managementThematique.createThematique(thematique);
        }
        return thematique;
    }

    @PutMapping("/update")
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority('Modification')")
    public ThematiqueEntity update(@RequestBody ThematiqueEntity thematique) {
        System.out.println("<Controller> Thématique - update : " + thematique.getNom() + " / id : " + thematique.getId());
        if (thematique != null) {
            managementThematique.updateThematique(thematique);
        }
        return thematique;
    }

    @GetMapping(value = "/findenfants/{idParent}", produces = {"application/json"})
    @PreAuthorize("hasAuthority('Consultation')")
    public List<ThematiqueEntity> find(@PathVariable("idParent") Long idParent) {
        System.out.println("<Controller> Thématique - find enfants de " + idParent);
        return managementThematique.findThematiquesEnfants(idParent);
    }

    @GetMapping(value = "/find/{idThematique}", produces = {"application/json"})
    @PreAuthorize("hasAuthority('Consultation')")
    public ThematiqueEntity thematiqueFind(@PathVariable("idThematique") Long id) {
        System.out.println("<Controller> Thématique - find id = " + id);
        return managementThematique.findThematique(id);
    }

    @DeleteMapping(value = "delete/{idThematique}")
    @PreAuthorize("hasAuthority('Suppression')")
    public void deleteThematique(@PathVariable("idThematique") Long id) {
        System.out.println("<Controller> Thématique - delete thématique " + id);
        managementThematique.deleteThematique(id);
    }

}
