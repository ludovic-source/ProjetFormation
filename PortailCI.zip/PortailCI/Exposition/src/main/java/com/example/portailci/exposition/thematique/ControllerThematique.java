package com.example.portailci.exposition.thematique;

import com.example.portailci.application.thematique.IManagementThematique;
import com.example.portailci.domain.thematique.ThematiqueEntity;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@RestController
@RequestMapping("/portailci/thematique")
public class ControllerThematique {

    @Autowired
    IManagementThematique managementThematique;

    @PostMapping(value="/create", produces={"application/json"})
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority('Création')")
    @ApiOperation(value = "Créer une thématique")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Thématique créée",
                examples=@Example(
                    value={
                            @ExampleProperty(
                                    mediaType = "Example json",
                                    value = "{\"nom\": \"Ligue 1\",\"description\": \"Championnat de France de football\",\"idParent\": 2}"
                            )
                    }
    ))
    })
    public ThematiqueEntity create(@RequestBody ThematiqueEntity thematique) {
        System.out.println("<Controller> Thématique - create : " + thematique.getNom());
        if (thematique != null) {
            managementThematique.createThematique(thematique);
        }
        return thematique;
    }

    @PostMapping("/upload")
    @ResponseStatus(HttpStatus.OK)
    //@PreAuthorize("hasAuthority('Création', 'Modification', 'Administration')")
    public String FileUpload(@RequestParam("file") MultipartFile file, RedirectAttributes redirectAttributes) {
        System.out.println("<Controller> Thématique - upload");
        if(file.isEmpty()) {
            redirectAttributes.addFlashAttribute("message", "Choisissez un fichier à uploader");
            return "redirect:uploadStatus";
        }
        try {
            byte[] bytes = file.getBytes();
            Path path = Paths.get("Exposition/src/main/resources/files/" + file.getOriginalFilename());
            Files.write(path, bytes);
            redirectAttributes.addFlashAttribute("message", "fichier " + file.getOriginalFilename() + "uploadé");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "redirect:/uploadStatus";
    }

    @PostMapping("/createupload")
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority('Création')")
    public ThematiqueEntity createupload(@ModelAttribute ThematiqueDTO thematiqueDTO) {
        System.out.println("<Controller> Thématique - createupload : file : " + thematiqueDTO.getFile().getOriginalFilename());
        System.out.println("<Controller> Thématique - createupload : thématique" + thematiqueDTO.getThematique().getNom());

        String imagePath = "Exposition/src/main/resources/files/" + thematiqueDTO.getFile().getOriginalFilename();
        ThematiqueEntity thematiqueRetour = null;
        try {
            byte[] bytes = thematiqueDTO.getFile().getOriginalFilename().getBytes();
            Path path = Paths.get(imagePath);
            Files.write(path, bytes);
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (thematiqueDTO.getThematique() != null) {
            thematiqueDTO.getThematique().setImagePath(imagePath);
            thematiqueRetour=managementThematique.createThematique(thematiqueDTO.getThematique());
        }
        return thematiqueRetour;
    }

    @PutMapping("/update")
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize("hasAuthority('Modification')")
    public ThematiqueEntity update(@RequestBody ThematiqueEntity thematique) {
        System.out.println("<Controller> Thématique - update : " + thematique.getNom() + " / id : " + thematique.getId());
        if (thematique != null) {
            managementThematique.updateThematique(thematique);
        }
        return thematique;
    }

    @GetMapping(value = "/findenfants/{idParent}", produces = {"application/json"})
    @PreAuthorize("hasAuthority('Consultation')")
    public List<ThematiqueEntity> find(@PathVariable("idParent") Long idParent) {
        System.out.println("<Controller> Thématique - find enfants de " + idParent);
        return managementThematique.findThematiquesEnfants(idParent);
    }

    @GetMapping(value = "/find/{idThematique}", produces = {"application/json"})
    @PreAuthorize("hasAuthority('Consultation')")
    public ThematiqueEntity thematiqueFind(@PathVariable("idThematique") Long id) {
        System.out.println("<Controller> Thématique - find id = " + id);
        return managementThematique.findThematique(id);
    }

    @DeleteMapping(value = "delete/{idThematique}")
    @PreAuthorize("hasAuthority('Suppression')")
    public void deleteThematique(@PathVariable("idThematique") Long id) {
        System.out.println("<Controller> Thématique - delete thématique " + id);
        managementThematique.deleteThematique(id);
    }

}
