package com.example.portailci.exposition.lien;

public class ControllerLienException extends RuntimeException {

    public ControllerLienException(String message) {
        super(message);
    }
}
