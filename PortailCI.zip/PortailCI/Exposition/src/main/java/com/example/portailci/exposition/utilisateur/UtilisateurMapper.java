package com.example.portailci.exposition.utilisateur;

import com.example.portailci.commun.AbstractMapper;
import com.example.portailci.domain.utilisateur.UtilisateurEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.validation.Valid;

@Component
public class UtilisateurMapper extends AbstractMapper<UtilisateurFullDTO, UtilisateurEntity> {

    private static final Logger LOG = LoggerFactory.getLogger(UtilisateurMapper.class);

    /**
     *
     * @param entity UtilisateurEntity présente dans la couche Domain
     * @return UtilisateurDTO
     */
    @Override
    public UtilisateurFullDTO mapToDto(UtilisateurEntity entity) {

        LOG.debug("En entrée : " + entity.toString());

        final UtilisateurFullDTO utilisateurDTO = new UtilisateurFullDTO();

        utilisateurDTO.setId(entity.getId());
        utilisateurDTO.setUID(entity.getUID());
        utilisateurDTO.setNom(entity.getNom());
        utilisateurDTO.setPrenom(entity.getPrenom());
        utilisateurDTO.setMotDePasse(entity.getMotDePasse());
        utilisateurDTO.setUOAffectation(entity.getUOAffectation());
        utilisateurDTO.setSiteExercice(entity.getSiteExercice());
        utilisateurDTO.setFonction(entity.getFonction());
        utilisateurDTO.setProfil(entity.getProfil());

        LOG.debug("En sortie : " + utilisateurDTO.toString());
        return utilisateurDTO;
    }

    /**
     *
     * @param dto UtilisateurDTO en retour du client
     * @return UtilisateurEntity
     */
    @Override
    public UtilisateurEntity mapToEntity(UtilisateurFullDTO dto) {

        final UtilisateurEntity entity = new UtilisateurEntity();

        LOG.debug("En entrée : " + dto.toString());

        entity.setId(dto.getId());
        entity.setUID(dto.getUID());
        entity.setNom(dto.getNom());
        entity.setPrenom(dto.getPrenom());
        entity.setMotDePasse(dto.getMotDePasse());
        entity.setUOAffectation(dto.getUOAffectation());
        entity.setSiteExercice(dto.getSiteExercice());
        entity.setFonction(dto.getFonction());
        entity.setProfil(dto.getProfil());

        LOG.debug("En sortie : " + entity.toString());

        return entity;
    }

    public UtilisateurEntity mapToEntity (@Valid UtilisateurLightDTO dto) {

        final UtilisateurEntity entity = new UtilisateurEntity();

        LOG.debug("En entrée : " + dto.toString());

        entity.setUID(dto.getUID());
        entity.setNom(dto.getNom());
        entity.setPrenom(dto.getPrenom());
        entity.setMotDePasse(dto.getMotDePasse());
        entity.setUOAffectation(dto.getUOAffectation());
        entity.setSiteExercice(dto.getSiteExercice());
        entity.setFonction(dto.getFonction());
        entity.setProfil(dto.getProfil());

        LOG.debug("En sortie : " + entity.toString());

        return entity;
    }
}
