package com.example.portailci.exposition.profil;

import com.example.portailci.exposition.droit.DroitDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;

import java.util.Set;

//Annotation Swagger permettant de personnaliser l'affichage de l'entité
@ApiModel(value = "Nouveau Profil", description = "Profil retourné par le client pour la création d'un nouveau profil")
// Annotation Spring permettant la validation du model
@Validated
public class ProfilLightDTO {

    @ApiModelProperty(notes = "Nom du profil")
    private String nom;
    @ApiModelProperty(notes = "Description du profil")
    private String description;
    @ApiModelProperty(notes = "Liste des droits rattachés au profil")
    private Set<DroitDTO> droits;

    public ProfilLightDTO() {
    }

    public ProfilLightDTO(String nom, String description, Set<DroitDTO> droits) {
        this.nom = nom;
        this.description = description;
        this.droits = droits;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Set<DroitDTO> getDroits() {
        return droits;
    }

    public void setDroits(Set<DroitDTO> droits) {
        this.droits = droits;
    }
}
