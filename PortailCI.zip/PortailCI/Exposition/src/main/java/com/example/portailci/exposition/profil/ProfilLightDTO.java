package com.example.portailci.exposition.profil;

import com.example.portailci.exposition.droit.DroitDTO;

import java.util.Set;

public class ProfilLightDTO {

    private String nom;
    private String description;
    private Set<DroitDTO> droits;

    public ProfilLightDTO() {
    }

    public ProfilLightDTO(String nom, String description, Set<DroitDTO> droits) {
        this.nom = nom;
        this.description = description;
        this.droits = droits;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Set<DroitDTO> getDroits() {
        return droits;
    }

    public void setDroits(Set<DroitDTO> droits) {
        this.droits = droits;
    }
}
