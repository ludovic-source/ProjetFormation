package com.example.portailci.domain.utilisateur;

public interface IUtilisateurRefogRepository {

    UtilisateurEntity getUtilisateurRefogVOByUid(String uid);
}
