package com.example.portailci.domain.utilisateur;

import com.example.portailci.domain.profil.ProfilEntity;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "UTILISATEUR")
public class UtilisateurEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    // Contrainte de longueur a exactement 6 caractere pour respecter le format UID
    // @Size(min = 6,max = 6)
    @NotNull
    @Column(unique = true)
    private String UID;

    @NotNull
    private String nom;

    @NotNull
    private String prenom;

    @NotNull
    private String motDePasse;

    //Reference UO sur 8 caracteres (alphanumerique)
    @NotNull
    private String UOAffectation;

    @NotNull
    private String siteExercice;

    @NotNull
    private String fonction;

    @ManyToOne()
    @JoinColumn(name = "PROFIL_ID")
    @NotNull
    private ProfilEntity profil;


    /**
     * Constructeur par defaut necessaire a Hibernate
     */
    public UtilisateurEntity() {

    }

    public UtilisateurEntity(String UID, String nom, String prenom, String motDePasse, String UOAffectation, String siteExercice, String fonction, ProfilEntity profil) {
        this.UID = UID;
        this.nom = nom;
        this.prenom = prenom;
        this.motDePasse = motDePasse;
        this.UOAffectation = UOAffectation;
        this.siteExercice = siteExercice;
        this.fonction = fonction;
        this.profil = profil;
    }

    public UtilisateurEntity(long id, String UID, String nom, String prenom, String motDePasse, String UOAffectation, String siteExercice, String fonction, ProfilEntity profil) {
        this.id = id;
        this.UID = UID;
        this.nom = nom;
        this.prenom = prenom;
        this.motDePasse = motDePasse;
        this.UOAffectation = UOAffectation;
        this.siteExercice = siteExercice;
        this.fonction = fonction;
        this.profil = profil;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUID() {
        return UID;
    }

    public void setUID(String UID) {
        this.UID = UID;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getMotDePasse() {
        return motDePasse;
    }

    public void setMotDePasse(String motDePasse) {
        this.motDePasse = motDePasse;
    }

    public String getUOAffectation() {
        return UOAffectation;
    }

    public void setUOAffectation(String UOAffectation) {
        this.UOAffectation = UOAffectation;
    }

    public String getSiteExercice() {
        return siteExercice;
    }

    public void setSiteExercice(String siteExercice) {
        this.siteExercice = siteExercice;
    }

    public String getFonction() {
        return fonction;
    }

    public void setFonction(String fonction) {
        this.fonction = fonction;
    }

    public ProfilEntity getProfil() {
        return profil;
    }

    public void setProfil(ProfilEntity profil) {
        this.profil = profil;
    }

    @Override
    public String toString() {
        return "UtilisateurEntity = {" +
                "id : '" + id + '\'' +
                ", Profil : '" + profil.getNom() + '\'' +
                ", UID : '" + UID + '\'' +
                ", Nom : '" + nom + '\'' +
                ", Prénom : '" + prenom + '\'' +
                ", MotDePasse : '"  + motDePasse + '\'' +
                ", UO Affectation : '" + UOAffectation + '\'' +
                ", Site d'exercice : '" + siteExercice + '\'' +
                ", Fonction : '" + fonction + '\'' +
                '}';
    }
}
