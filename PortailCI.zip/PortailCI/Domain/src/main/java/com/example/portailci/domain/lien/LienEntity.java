package com.example.portailci.domain.lien;

import com.example.portailci.domain.thematique.ThematiqueEntity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Table(name = "liens")
public class LienEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Integer id;

    @NotNull
    String url;
    @NotNull
    String nom;
    @NotNull
    String description;
    @NotNull
    String statut;          // valeurs possibles : "publié restreint" / "publié" / "dépublié"
    @NotNull
    Boolean mode_affichage; // true = nouvel onglet ; false = nouvelle fenêtre
    @NotNull
    LocalDateTime date_publication_restreinte;
    LocalDateTime date_publication;
    LocalDateTime date_depublication;

    @ManyToOne
    @NotNull
    ThematiqueEntity thematique;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    public Boolean getMode_affichage() {
        return mode_affichage;
    }

    public void setMode_affichage(Boolean mode_affichage) {
        this.mode_affichage = mode_affichage;
    }

    public LocalDateTime getDate_publication_restreinte() {
        return date_publication_restreinte;
    }

    public void setDate_publication_restreinte(LocalDateTime date_publication_restreinte) {
        this.date_publication_restreinte = date_publication_restreinte;
    }

    public LocalDateTime getDate_publication() {
        return date_publication;
    }

    public void setDate_publication(LocalDateTime date_publication) {
        this.date_publication = date_publication;
    }

    public LocalDateTime getDate_depublication() {
        return date_depublication;
    }

    public void setDate_depublication(LocalDateTime date_depublication) {
        this.date_depublication = date_depublication;
    }

    public ThematiqueEntity getThematique() {
        return thematique;
    }

    public void setThematique(ThematiqueEntity thematique) {
        this.thematique = thematique;
    }
}
