package com.example.portailci.application.lien;

public class LienNotFoundException extends RuntimeException {

    public LienNotFoundException(String message) {
        super(message);
    }

}
