package com.example.portailci.application.lien;

public class ManagementLienException extends RuntimeException {

    public ManagementLienException(String message) {
        super(message);
    }

}
