package com.example.portailci.application.lien;

public class LienControleDonneesException extends RuntimeException {

    public LienControleDonneesException(String message) {
        super(message);
    }
}
