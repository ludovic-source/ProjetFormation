package com.example.portailci.application.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

public class AppAuthProvider extends DaoAuthenticationProvider {

    private static Logger LOGGER = LoggerFactory.getLogger(AppAuthProvider.class);

    @Autowired
    UserDetailsService userDetailsService;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {

        UsernamePasswordAuthenticationToken auth = (UsernamePasswordAuthenticationToken) authentication;

        String name = auth.getName();
        String password = auth.getCredentials().toString();

        LOGGER.debug("Auth.getname() = " + auth.getName());
        LOGGER.debug("Auth.getCredentials() = " + auth.getCredentials().toString());

        UserDetails user = userDetailsService.loadUserByUsername(name);

/*      System.out.println("//////////////////////////////////////////////////////////////////////////");
        System.out.println("//////////////////////////////////////////////////////////////////////////");
        System.out.println("Comparaison de mots de passe :");
        System.out.println("passwordEncoder().encode(password) = " + passwordEncoder().encode(password));
        System.out.println("User.getPassword() = " + user.getPassword());
        System.out.println("//////////////////////////////////////////////////////////////////////////");
        System.out.println("//////////////////////////////////////////////////////////////////////////");
*/

        if(user != null && passwordEncoder().matches(password,user.getPassword()) == true ) {

            LOGGER.debug("Authentification réussie !");
            return new UsernamePasswordAuthenticationToken(user, null, user.getAuthorities());
        }

        System.out.println();
        LOGGER.debug("Authentification échouée.");
        throw new BadCredentialsException("Authentification échouée. Merci de saisir votre UID et mot de passe");
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return true;
    }
}
