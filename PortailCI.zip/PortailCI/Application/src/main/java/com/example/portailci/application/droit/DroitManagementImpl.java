package com.example.portailci.application.droit;

import com.example.portailci.domain.droit.DroitEntity;
import com.example.portailci.domain.droit.IRepositoryDroit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Set;

@Service
@Transactional
public class DroitManagementImpl implements IDroitManagement {

    @Autowired
    IRepositoryDroit repositoryDroit;

    private static final Logger LOG  = LoggerFactory.getLogger(DroitManagementImpl.class);

    @Override
    public DroitEntity findById(Long id) {
        LOG.debug("Couche Application/DroiManagementImpl/findById " + id);
        return repositoryDroit.findById(id);
    }

    @Override
    public Set<DroitEntity> findAll() {
        LOG.debug("Couche Application/DroiManagementImpl/findAll");
        return repositoryDroit.findAll();
    }
}
