package com.example.portailci.application.profil;

import com.example.portailci.domain.profil.IRepositoryProfil;
import com.example.portailci.domain.profil.ProfilEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Set;

@Service
@Transactional
public class ProfilManagementImpl implements IProfilManagement {

    @Autowired
    private IRepositoryProfil  repositoryProfil;

    private static final Logger logger  = LoggerFactory.getLogger(ProfilManagementImpl.class);

    @Override
    public ProfilEntity create(ProfilEntity profil) {
        return repositoryProfil.create(profil);
    }

    @Override
    public ProfilEntity findByID(Long id) {
        return repositoryProfil.findById(id);
    }

    @Override
    public void delete(Long id) {
        repositoryProfil.delete(id);
    }

    @Override
    public ProfilEntity update(ProfilEntity utilisateur) {
        return repositoryProfil.update(utilisateur);
    }

    @Override
    public Set<ProfilEntity> findAll() {
        return repositoryProfil.findAll();
    }
}
