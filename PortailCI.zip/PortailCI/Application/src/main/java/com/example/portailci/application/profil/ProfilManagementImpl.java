package com.example.portailci.application.profil;

import com.example.portailci.domain.exception.NotFoundException;
import com.example.portailci.domain.profil.IRepositoryProfil;
import com.example.portailci.domain.profil.ProfilEntity;
import com.example.portailci.domain.utilisateur.IRepositoryUtilisateur;
import com.example.portailci.domain.utilisateur.UtilisateurEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

@Service
@Transactional
public class ProfilManagementImpl implements IProfilManagement {

    @Autowired
    private IRepositoryProfil  repositoryProfil;

    @Autowired
    private IRepositoryUtilisateur repositoryUtilisateur;

    private static final Logger logger  = LoggerFactory.getLogger(ProfilManagementImpl.class);

    @Override
    public ProfilEntity create(ProfilEntity profil) {
        return repositoryProfil.create(profil);
    }

    @Override
    public ProfilEntity findByID(Long id) {
        ProfilEntity profilEntity = repositoryProfil.findById(id);
        if(profilEntity != null) return profilEntity;
        else throw  new NotFoundException("Aucun profil ayant l'id : " + id + " n'a été trouvé.");
    }

    @Override
    public ProfilEntity findProfilOfConnectedUser() {

        // On récupère le contexte Spring Security
        SecurityContext context = SecurityContextHolder.getContext();

        // On récupère l'objet de type Authentication qui contient le nom d'utilisateur (éventuellement le mot de passe, ici non inséré) et les authorities (ici, les droits)
        Authentication authentication = context.getAuthentication();

        // On contrôle que l'utilisateur est bien authentifié
        if(authentication.isAuthenticated()) {

            // On récupère l'objet principal
            Object principal = authentication.getPrincipal();

            // On récupère le username (ici l'uid servant d'identifiant de connexion)
            final String uid = ((UserDetails) principal).getUsername();

            // On va rechercher l'utilisateur en base
            UtilisateurEntity utilisateur = repositoryUtilisateur.findByUid(uid);
            ProfilEntity profil = utilisateur.getProfil();

            return profil;
        }
        else throw new RuntimeException("Utilisateur non connecté");

    }

    @Override
    public void delete(Long id) {
        ProfilEntity profilASupprimer = repositoryProfil.findById(id);
        if(profilASupprimer != null) repositoryProfil.delete(profilASupprimer);
        else throw new NotFoundException("Aucun profil ayant l'id : " + id + " n'a été trouvé.");
    }

    @Override
    public ProfilEntity update(ProfilEntity utilisateur) {
        return repositoryProfil.update(utilisateur);
    }

    @Override
    public Set<ProfilEntity> findAll() {
        return repositoryProfil.findAll();
    }
}
