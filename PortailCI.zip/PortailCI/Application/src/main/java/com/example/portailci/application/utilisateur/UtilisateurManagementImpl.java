package com.example.portailci.application.utilisateur;

import com.example.portailci.domain.utilisateur.IRepositoryUtilisateur;
import com.example.portailci.domain.utilisateur.UtilisateurEntity;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;


@Service
@Transactional
public class UtilisateurManagementImpl implements IUtilisateurManagement {

    @Autowired
    private IRepositoryUtilisateur repositoryUtilisateur;

    @Autowired
    private PasswordEncoder passwordEncoder;


    private static final Logger logger = LoggerFactory.getLogger(UtilisateurManagementImpl.class);

    @Override
    public UtilisateurEntity create(UtilisateurEntity utilisateur) {

        //On encode le mot de passe de l'utilisateur et on lui affecte
        utilisateur.setMotDePasse(passwordEncoder.encode(utilisateur.getUID()));
        return repositoryUtilisateur.create(utilisateur);
    }

    @Override
    public UtilisateurEntity findByUID(String utilisateurUid, boolean fromRefog) {

        logger.debug("Méthode findByUID - String utilisateurUid = " + utilisateurUid + " - boolean fromRefog = " + fromRefog );
        if(fromRefog == false){
            UtilisateurEntity utilisateurFromDatabase = repositoryUtilisateur.findByUID( utilisateurUid, false );
            logger.debug("Retour de la méthode findByUID du repositoryUtilisateur FROM DATABASE = " + utilisateurFromDatabase);
            return repositoryUtilisateur.findByUID( utilisateurUid, false );
        }
        else{
            UtilisateurEntity utilisateurFromRefog = repositoryUtilisateur.findByUID( utilisateurUid, true );
            logger.debug("Retour de la méthode findByUID du repositoryUtilisateur FROM REFOG = " + utilisateurFromRefog);
            return utilisateurFromRefog;
        }
    }

    @Override
    public UtilisateurEntity findByID(Long id) {
        return repositoryUtilisateur.findById(id);
    }

    @Override
    public void delete(Long id) {
        repositoryUtilisateur.delete(id);
    }

    @Override
    public UtilisateurEntity update(UtilisateurEntity utilisateur) {
        return repositoryUtilisateur.update(utilisateur);
    }

    @Override
    public List<UtilisateurEntity> findAll() {

        return repositoryUtilisateur.findAll();
    }
}
