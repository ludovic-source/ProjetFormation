package com.example.portailci.application.utilisateur;

import com.example.portailci.domain.utilisateur.IRepositoryUtilisateur;
import com.example.portailci.domain.utilisateur.UtilisateurEntity;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;


@Service
@Transactional
public class UtilisateurManagementImpl implements IUtilisateurManagement {

    @Autowired
    private IRepositoryUtilisateur repositoryUtilisateur;

    @Autowired
    private PasswordEncoder passwordEncoder;


    private static final Logger LOG  = LoggerFactory.getLogger(UtilisateurManagementImpl.class);

    @Override
    public UtilisateurEntity create(UtilisateurEntity utilisateur) {
        utilisateur.setMotDePasse(passwordEncoder.encode(utilisateur.getUID()));
        return repositoryUtilisateur.create(utilisateur);
    }

    @Override
    public UtilisateurEntity findByUID(String utilisateurUid) {

        return repositoryUtilisateur.findByUID( utilisateurUid );
    }

    @Override
    public UtilisateurEntity findByID(Long id) {
        return repositoryUtilisateur.findById(id);
    }

    @Override
    public void delete(Long id) {
        repositoryUtilisateur.delete(id);
    }

    @Override
    public UtilisateurEntity update(UtilisateurEntity utilisateur) {
        return repositoryUtilisateur.update(utilisateur);
    }

    @Override
    public List<UtilisateurEntity> findAll() {

        return repositoryUtilisateur.findAll();
    }
}
