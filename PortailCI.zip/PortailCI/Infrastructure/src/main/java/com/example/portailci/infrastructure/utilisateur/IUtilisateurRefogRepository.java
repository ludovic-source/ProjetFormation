package com.example.portailci.infrastructure.utilisateur;

public interface IUtilisateurRefogRepository {

    UtilisateurRefogVO getUtilisateurRefogVOByUid(String uid);
}
