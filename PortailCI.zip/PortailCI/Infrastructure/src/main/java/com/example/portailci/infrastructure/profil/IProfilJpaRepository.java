package com.example.portailci.infrastructure.profil;

import com.example.portailci.domain.profil.ProfilEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IProfilJpaRepository extends JpaRepository<ProfilEntity, Long> {
}
