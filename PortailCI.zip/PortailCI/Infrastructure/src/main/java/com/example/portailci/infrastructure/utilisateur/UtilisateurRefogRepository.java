package com.example.portailci.infrastructure.utilisateur;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.util.Set;

@Component
public class UtilisateurRefogRepository implements IUtilisateurRefogRepository {

    private static Logger logger = LoggerFactory.getLogger(UtilisateurRefogRepository.class);

    private Set<UtilisateurRefogVO> utilisateursRefog;

    public UtilisateurRefogRepository(Set<UtilisateurRefogVO> utilisateursRefog) {
        this.utilisateursRefog = utilisateursRefog;

        UtilisateurRefogVO utilisateur1 = new UtilisateurRefogVO("139696","JOLY","Christophe","14578A65","Valmy 2","Développeur");
        UtilisateurRefogVO utilisateur2 = new UtilisateurRefogVO("a30607","TAVIGNOT","Bertrand","41796B12","Papeete","Développeur");
        UtilisateurRefogVO utilisateur3 = new UtilisateurRefogVO("123456","ABELLI","Rudy","12463258","Tassigny","CIL");
        UtilisateurRefogVO utilisateur4 = new UtilisateurRefogVO("000000","RENAUD","Eric","12463258","Tassigny","CIL");
        UtilisateurRefogVO utilisateur5 = new UtilisateurRefogVO("654321","FRANCOIS","Jean-Jacques","12463258","Tassigny","CIL");
        UtilisateurRefogVO utilisateur6 = new UtilisateurRefogVO("987654","CHIMIER","Ludovic","74102R85","Paris","Développeur");

        this.utilisateursRefog.add(utilisateur1);
        this.utilisateursRefog.add(utilisateur2);
        this.utilisateursRefog.add(utilisateur3);
        this.utilisateursRefog.add(utilisateur4);
        this.utilisateursRefog.add(utilisateur5);
        this.utilisateursRefog.add(utilisateur6);
    }

    public Set<UtilisateurRefogVO> getUtilisateursRefog() {
        return utilisateursRefog;
    }

    public UtilisateurRefogVO getUtilisateurRefogVOByUid (String uid) {

        UtilisateurRefogVO utilisateurRefogVO = null;
        logger.debug("Méthode  getUtilisateurRefogVOByUid - String uid = " + uid);
        for (UtilisateurRefogVO utilisateur : this.utilisateursRefog){
            logger.debug("Méthode  getUtilisateurRefogVOByUid - Boucle sur le set d'utilisateurRefogVO");
            logger.debug("Méthode  getUtilisateurRefogVOByUid - utilisateurRefogVO uid = " + utilisateur.getUID() + " - Correspondance = " + (utilisateur.getUID()).equals(uid));

            if((utilisateur.getUID()).equals(uid)){
                utilisateurRefogVO = new UtilisateurRefogVO();
                utilisateurRefogVO.setUID(utilisateur.getUID());
                utilisateurRefogVO.setNom(utilisateur.getNom());
                utilisateurRefogVO.setPrenom(utilisateur.getPrenom());
                utilisateurRefogVO.setUOAffectation(utilisateur.getUOAffectation());
                utilisateurRefogVO.setSiteExercice(utilisateur.getSiteExercice());
                utilisateurRefogVO.setFonction(utilisateur.getFonction());
            }

        }
        logger.debug("Méthode  getUtilisateurRefogVOByUid - Sortie de boucle = " + utilisateurRefogVO.toString());

        return utilisateurRefogVO;

    }
}
