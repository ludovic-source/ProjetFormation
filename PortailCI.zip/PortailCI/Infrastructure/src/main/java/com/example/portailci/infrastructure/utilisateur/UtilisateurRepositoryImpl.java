package com.example.portailci.infrastructure.utilisateur;

import com.example.portailci.domain.exception.AlreadyExistsException;
import com.example.portailci.domain.exception.NotFoundException;
import com.example.portailci.domain.utilisateur.IRepositoryUtilisateur;
import com.example.portailci.domain.utilisateur.UtilisateurEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class UtilisateurRepositoryImpl implements IRepositoryUtilisateur {

    private static Logger logger = LoggerFactory.getLogger(UtilisateurRepositoryImpl.class);

    @Autowired
    private IUtilisateurRefogRepository utilisateurRefogRepository;

    @Autowired
    private IUtilisateurJpaRepository utilisateurJpaRepository;

    @Autowired
    private UtilisateurRefogMapper utilisateurRefogMapper;

    private static UtilisateurEntity utilisateurEntity;


    @Override
    public UtilisateurEntity findByUID(String uid, boolean fromRefog) {

        logger.debug("Méthode findByUid - String uid = " + uid + " boolean fromRefog = " + fromRefog);

        //Si le booleen est false, on redirige vers une recherche en base de donnée
        if(fromRefog == false) {
            try {
                logger.debug("Dans if fromRefog == false => Requête vers le JpaRepository");

                UtilisateurEntity utilisateur = utilisateurJpaRepository.findByUID(uid);
                logger.debug("Retour de la méthode findByUID du JpaRepository = " + utilisateur);
                if(utilisateur != null) {
                    return utilisateur;
                }
                else{
                    throw new Exception();
                }
            }
            catch(Exception e) {
                throw new NotFoundException("Aucun utilisateur portant l'UID : " + uid + " n'a été trouvé : " + e.getMessage());
            }
        }
        //Sinon, on redirige vers le repository simulant le Refog - A adapter plus tard avec un appel API externe
        else{
            try {
                logger.debug("Dans if fromRefog == true => Requête vers le RefogRepository");

                UtilisateurRefogVO utilisateurRefogVO = utilisateurRefogRepository.getUtilisateurRefogVOByUid(uid);
                logger.debug("utilisateurRefogVO avant mapper= " + utilisateurRefogVO.toString());

                UtilisateurEntity utilisateur = utilisateurRefogMapper.mapToEntity(utilisateurRefogVO);
                logger.debug("Retour de la méthode getUtilisateurRefogVOByUid du RefogRepository après le mapper - UtilisateurEntity = " + utilisateur);

                return utilisateur;
            }
            catch(Exception e){

                throw new NotFoundException("Aucun utilisateur portant l'UID : " + uid + " n'a été trouvé dans le REFOG : " + e.getMessage());
            }

        }


    }

    @Override
    public UtilisateurEntity findById(Long id) throws NotFoundException{
        Optional<UtilisateurEntity> utilisateur = utilisateurJpaRepository.findById(id);
        if (utilisateur.isPresent()) {
            utilisateur.ifPresent(TheUtilisateur -> lambdaFindById(TheUtilisateur));
            return this.utilisateurEntity;
        }
        else {
            throw new NotFoundException("Aucun utilisateur portant l'id : " + id + " n'a été trouvé.");
        }
    }

    public static void lambdaFindById(UtilisateurEntity utiilisateur) {
        utilisateurEntity = utiilisateur;
    }

    @Override
    public List<UtilisateurEntity> findAll() {
        return utilisateurJpaRepository.findAll();
    }

    @Override
    public UtilisateurEntity create(UtilisateurEntity utilisateur) {

        try{
            return utilisateurJpaRepository.save(utilisateur);
        } catch(Exception e){
            throw new AlreadyExistsException("Un utilisateur avec l'UID :" + utilisateur.getUID() + " existe déjà : " + e.getMessage());
        }
    }

    @Override
    public UtilisateurEntity update(UtilisateurEntity utilisateur) {

        return utilisateurJpaRepository.save(utilisateur);
    }

    @Override
    public void delete(Long id) {
        UtilisateurEntity utilisateur = this.findById(id);

        utilisateurJpaRepository.delete(utilisateur);
    }


}
