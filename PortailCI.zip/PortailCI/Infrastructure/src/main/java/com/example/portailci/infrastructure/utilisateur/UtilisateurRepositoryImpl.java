package com.example.portailci.infrastructure.utilisateur;

import com.example.portailci.domain.exception.AlreadyExistsException;
import com.example.portailci.domain.exception.NotFoundException;
import com.example.portailci.domain.utilisateur.IRepositoryUtilisateur;
import com.example.portailci.domain.utilisateur.UtilisateurEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class UtilisateurRepositoryImpl implements IRepositoryUtilisateur {

    @Autowired
    IUtilisateurJpaRepository utilisateurJpaRepository;

    private static UtilisateurEntity utilisateurEntity;

    @Override
    public UtilisateurEntity findByUID(String uid) {

        final UtilisateurEntity utilisateurEntity = utilisateurJpaRepository.findByUID(uid);

        if(utilisateurEntity != null) {
            return utilisateurEntity;
        }
        else {
            throw new NotFoundException("Aucun utilisateur portant l'UID : " + uid + " n'a été trouvé.");
        }
    }

    @Override
    public UtilisateurEntity findById(Long id) throws NotFoundException{
        Optional<UtilisateurEntity> utilisateur = utilisateurJpaRepository.findById(id);
        if (utilisateur.isPresent()) {
            utilisateur.ifPresent(TheUtilisateur -> lambdaFindById(TheUtilisateur));
            return this.utilisateurEntity;
        }
        else {
            throw new NotFoundException("Aucun utilisateur portant l'id : " + id + " n'a été trouvé.");
        }
    }

    public static void lambdaFindById(UtilisateurEntity utiilisateur) {
        utilisateurEntity = utiilisateur;
    }

    @Override
    public List<UtilisateurEntity> findAll() {
        return utilisateurJpaRepository.findAll();
    }

    @Override
    public UtilisateurEntity create(UtilisateurEntity utilisateur) {

        try{
            return utilisateurJpaRepository.save(utilisateur);
        } catch(Exception e){
            throw new AlreadyExistsException("Un utilisateur avec l'UID :" + utilisateur.getUID() + " existe déjà : " + e.getMessage());
        }
    }

    @Override
    public UtilisateurEntity update(UtilisateurEntity utilisateur) {

        return utilisateurJpaRepository.save(utilisateur);
    }

    @Override
    public void delete(Long id) {
        UtilisateurEntity utilisateur = this.findById(id);

        utilisateurJpaRepository.delete(utilisateur);
    }


}
